const mongoose = require('mongoose');
const FoodRegistration = new mongoose.Schema({
    food_name : {
        type : String,
        require : true
    },
    qty:{
        type : Number,
        require : true,
    },
    price:{
        type : Number,
        require : true,
    }    
});
module.exports = mongoose.model('counter', FoodRegistration, 'counter');