const mongoose = require('mongoose');

const FoodOrder = new mongoose.Schema({
    food_id : {
        type : mongoose.Schema.Types.ObjectId,
        ref:"counter",
        require : true
    }
});
module.exports = mongoose.model('order', FoodOrder, 'order');   