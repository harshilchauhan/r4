const express = require("express");
const router = express.Router();
const order = require('../Models/order_model');

router.post("/order", async (req, res) => {
    try {
        const newOrder = new order({
            food_id:req.body.food_id
        })
        const my = await newOrder.save();
       
        return res.status(201).json(my);
    } catch (error) {
        return res.status(201).send(error);
    }
})


router.get("/orderdata",async(req,res)=>{
    try{
        const newCart = await order.find().populate('food_id');
        return res.status(201).json(newCart);
    }catch(error){
        return res.status(201).send(error);
    }
})

router.delete("/orderdelete/:id",async(req,res)=>{
    try{
        const newCart = await order.findByIdAndDelete(req.params.id);
        return res.status(201).json(newCart);
    }catch(error){
        return res.status(201).send(error);
    }
})

module.exports = router;