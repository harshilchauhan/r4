const express = require('express');
const router = express.Router();
const FoodRegistration = require('../Models/test_model');

//Insert Data
router.post('/insert', async(req, res) => {
    console.log(req.body);
    const add = new FoodRegistration({
        food_name: req.body.food_name,
        qty: req.body.qty,
        price: req.body.price,
    })
    const data = await add.save();
    return res.status(201).json(data);
})

//Display Data 
router.get('/DispData', async(req, res) => {
    const data = await FoodRegistration.find();
    return res.status(200).json(data);
})

//update data
router.put("/update/:id", async(req, res) => {
    const updata = await FoodRegistration.findByIdAndUpdate(req.params.id, req.body, { new: true })
    return res.json(updata);
})
 


module.exports = router;  