import './App.css';
import { Routes, Route } from "react-router-dom"
import Header from './Component/Header';
import Display from './Component/Display';
import NewBill from './Component/NewBill';
import Order from './Component/Order';

function App() {
    return ( 
        <>
        <Header />
        <Routes>
            <Route path="/" element={<Display/>}/>
            <Route path="/redux" element={<NewBill/>}/>
            <Route path="/myorder" element={<Order/>}/>
        </Routes> 
        </> 
    );
}

export default App;