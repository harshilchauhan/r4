import { configureStore } from '@reduxjs/toolkit';
import billReducer from '../Bill_Redux/billSlice';

export const Store = configureStore({
    reducer: {
        bill: billReducer,
    },
});
