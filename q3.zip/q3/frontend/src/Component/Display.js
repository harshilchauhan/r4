import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const Display = () => {

  const [bill, setBill] = useState([]);
  const [total, setTotal] = useState(0);
  const orderPage = useNavigate();

  useEffect(() => {
    DisplayBill();
  }, [])

  const DisplayBill = async () => {
    const response = await axios.get('http://127.0.0.1:5000/api/DispData')
    const mydata = response.data;
    setBill(mydata);
    calculateTotal(mydata);
    
  }

  const ManageQty = async (id, newQty) => {
    if (newQty < 1) {
      alert("qty is already 1");
    } else {
      const upPrice = await axios.put(`http://127.0.0.1:5000/api/update/${id}`, { qty: newQty })
      DisplayBill();
    }
  }

  const calculateTotal = (billData) => {
    const newTotal = billData.reduce((acc, item) => {
      return acc + item.price * item.qty;
    }, 0);

    setTotal(newTotal);
  };

  const CheckOut = () =>{
    try {
         bill.map(async(proid)=>{
           await axios.post('http://127.0.0.1:5000/orderapi/order', { food_id: proid._id });
        }) 
        orderPage('/myorder');
    } catch (error) {
      console.error('Error during checkout:', error);
    }
  }

  return (
    <>
      <div className='text-center'>
        <p class="text-danger bg-dark">Use State</p>
      </div>
      <div className='mx-5 my-5'>
        <table class="table">
          <thead>
            <tr>
              <th scope="col">Name</th>
              <th scope="col" className='px-5'>Qty</th>
              <th scope="col">Price</th>
            </tr>
          </thead>
          <tbody>
            {bill.map((data) => {

              return (<>
                <tr>
                  <td>{data.food_name}</td>
                  <td><button type="button" class="btn btn-danger mx-2" onClick={() => ManageQty(data._id, data.qty + 1)}>+</button>
                    {data.qty}
                    <button type="button" class="btn btn-danger mx-2" onClick={() => ManageQty(data._id, data.qty - 1)}>-</button>
                  </td>
                  <td>{data.price * data.qty}</td>

                </tr>
              </>)
            })}

          </tbody>
        </table>
      </div>
      <div className='text-center'>
        <p class="text-danger">Total Price: {total} /- 
          <button type="button" class="btn btn-primary mx-2" onClick={()=>CheckOut()}>Check Out</button> 
        </p>
        
      </div>

    </>
  )
}

export default Display