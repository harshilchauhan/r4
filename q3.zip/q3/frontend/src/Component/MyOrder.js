import React, { useEffect, useState } from 'react';
import axios from 'axios';

const MyOrder = () => {

    const [GetOrder, setOrder] = useState([])
    const [total, setTotal] = useState(0);

    const DisplayCart = async () => {
        const response = await axios.get('http://127.0.0.1:5000/orderapi/orderdata')
        const setData = await response.data;
        setOrder(setData);
        calculateTotal(setData);
    }
    useEffect(() => {
        DisplayCart()
    }, [])

    const calculateTotal = (billData) => {
        const newTotal = billData.reduce((acc, item) => {
            return acc + item.food_id.price * item.food_id.qty;
        }, 0);

        setTotal(newTotal);
    };
    return (
        <>
            <div className='container mx-2 my-4'>
                <div className="row g-3">
                    {GetOrder.map((post, key) => {
                        return (<>
                            <div className="col-3">
                                <div className="card" style={{ width: "17rem" }}>
                                    <div className="card-body" key={key}>
                                        <h5 className="card-title">Name: {post.name}</h5>
                                        <h5 className="card-title">Mobile: {post.mobile}</h5>
                                        <h5 className="card-title">Email: {post.email}</h5>
                                        <h5 className="card-title">Product Name: {post.food_id.food_name}</h5>
                                        <h6 className="card-title">Total: {post.food_id.price * post.food_id.qty}/-</h6>

                                    </div>
                                </div>

                            </div>
                        </>)
                    })}
                    <p>Final Total: {total}/-</p>
                </div>
            </div>
        </>
    )
}

export default MyOrder