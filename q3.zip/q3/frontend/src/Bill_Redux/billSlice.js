import { createSlice } from "@reduxjs/toolkit";

const billSlice = createSlice({
    name: 'bill',
    initialState: [],
    reducers: { 
      setBill: (state, action) => {
        return action.payload;
      },
      updateQty: (state, action) => {
        const { id, qty } = action.payload;
        const itemIndex = state.findIndex((item) => item._id === id);
        if (itemIndex !== -1) {
          state[itemIndex].qty = qty;
        }
      },
    },
  });
  
  export const { setBill, updateQty } = billSlice.actions;
  export default billSlice.reducer;